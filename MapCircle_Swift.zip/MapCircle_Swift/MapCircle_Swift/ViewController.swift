//
//  ViewController.swift
//  MapCircle_Swift
//
//  Created by Prathyusha kotagiri on 10/21/15.
//  Copyright (c) 2015 Prathyusha kotagiri. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController,MKMapViewDelegate,CLLocationManagerDelegate {
    
    @IBOutlet weak var map: MKMapView!
    
    var locationManager:CLLocationManager!
    var userLocation:CLLocation?
    var sourceAnnotation:MKPointAnnotation!
    
    var _1KmCircle:MKCircle!
    var _3KmCircle:MKCircle!
    var _5KmCircle:MKCircle!
    
    var iosVersion:Double!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let device = UIDevice.currentDevice()
        self.iosVersion = NSString(string: device.systemVersion).doubleValue
        
        getCurrentLocation()
    }
    
    //Mark: Current Location
    
    func getCurrentLocation(){
        
        locationManager = CLLocationManager()
        
        if #available(iOS 8.0, *) {
            locationManager.requestWhenInUseAuthorization()
        }
        
        locationManager.delegate = self;
        locationManager.startUpdatingLocation()
    }
    
    //MARK:CLLocationManager delegates
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        userLocation = locations[0]
        
        //txtSource.text = "\(userLocation!.coordinate.latitude),\(userLocation!.coordinate.longitude)"
        
        reverseGeocoding()
        
        //TODO: Stop location updation
        locationManager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        
        if #available(iOS 8.0, *) {
            let alert:UIAlertController = UIAlertController(title:"Location manager failed", message: nil, preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated:true, completion: nil)
        } else {
            // Fallback on earlier versions
        }
        
    }
    
    //MARK: Reverse Geocoding
    
    func reverseGeocoding(){
        
        let geocoder:CLGeocoder = CLGeocoder()
        
        geocoder.reverseGeocodeLocation(self.userLocation!, completionHandler: {(placemarks, error) -> Void in
            
            if (error != nil) {
                print("Reverse geocoder failed with error" + error!.localizedDescription)
                return
            }
            
            if placemarks!.count>0 {
                
                let placeMark = placemarks![0] 
                
                let title:String = "\(placeMark.thoroughfare!),\(placeMark.locality!),\(placeMark.administrativeArea!)"
                
                if !(self.sourceAnnotation != nil){
                    self.sourceAnnotation = MKPointAnnotation()
                }
                
                self.sourceAnnotation.coordinate = self.userLocation!.coordinate
                self.sourceAnnotation.title = title
                self.sourceAnnotation.subtitle = "Source"
                self.map.addAnnotation(self.sourceAnnotation)
                
                //self.addRadiusCircle(self.userLocation!)
                
                self._1KmCircle = MKCircle(centerCoordinate: self.userLocation!.coordinate, radius: 1000 as CLLocationDistance)
                self._1KmCircle.title = "inner"
                
                self.show1KMCircle(self._1KmCircle)
                
                self._3KmCircle = MKCircle(centerCoordinate: self.userLocation!.coordinate, radius: 3000 as CLLocationDistance)
                self._3KmCircle.title = "middle"
                
                self._5KmCircle = MKCircle(centerCoordinate: self.userLocation!.coordinate, radius: 5000 as CLLocationDistance)
                self._5KmCircle.title = "outer"
                
            } else {
                print("Problem with the data received from geocoder")
            }
            
        })
    }
    
    //MARK: 1KM Circle
    @IBAction func show1KMCircle(sender: AnyObject) {
        
        removeOverlaysFromMapview()
        
        self.map.addOverlay(self._1KmCircle)
        
        if(self.iosVersion>=7.0)
        {
            ZoomTheMapView(6700)
        }else{
        self.map.setRegion(MKCoordinateRegionMake(self.userLocation!.coordinate, MKCoordinateSpan(latitudeDelta: 0.024,longitudeDelta: 0.024)), animated: true)
        }
        
    }
    
    //MARK: 3KM Circle
    @IBAction func show3KMCircle(sender: AnyObject) {
        
        removeOverlaysFromMapview()
        
        self.map.addOverlay(self._1KmCircle)
        self.map.addOverlay(self._3KmCircle)
        
        if(self.iosVersion>=7.0)
        {
            ZoomTheMapView(20000)
        }else{
            self.map.setRegion(MKCoordinateRegionMake(self.userLocation!.coordinate, MKCoordinateSpan(latitudeDelta: 0.073,longitudeDelta: 0.073)), animated: true)
        }
    }
    
    //MARK: 5KM Circle
    @IBAction func show5KMCircle(sender: AnyObject) {
        
        removeOverlaysFromMapview()
        
        self.map.addOverlay(self._1KmCircle)
        self.map.addOverlay(self._3KmCircle)
        self.map.addOverlay(self._5KmCircle)
        
        if(self.iosVersion>=7.0)
        {
            ZoomTheMapView(33000)
        }else{
            self.map.setRegion(MKCoordinateRegionMake(self.userLocation!.coordinate, MKCoordinateSpan(latitudeDelta: 0.121,longitudeDelta: 0.121)), animated: true)
        }
    }
    
    //MARK:Zoom Mapview for(IOS 7.0)
    func ZoomTheMapView(altitude:CLLocationDistance){
        
        let coordsGarage:CLLocationCoordinate2D = CLLocationCoordinate2DMake(self.userLocation!.coordinate.latitude, self.userLocation!.coordinate.longitude)
        
        let camera:MKMapCamera = MKMapCamera(lookingAtCenterCoordinate: coordsGarage, fromEyeCoordinate: coordsGarage, eyeAltitude: altitude)
        
        self.map.pitchEnabled = false
        self.map.camera = camera
    }

    //MARK: Remove overlays
    func removeOverlaysFromMapview(){
        
        let array:[MKOverlay]? = map.overlays as? [MKOverlay]
        
        var i :Int
        
        if array != nil
        {
            for (i=0; i<array!.count; i++) {
                
                let overlay : MKOverlay = array![i] as MKOverlay
                self.map.removeOverlay(overlay)
            }
            
        }
        
    }

    //MARK: MKMapView Delegate Methods
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        
        var pinView = self.map.dequeueReusableAnnotationViewWithIdentifier("CustomPin") as? MKPinAnnotationView
        
        if pinView==nil
        {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "CustomPin")
            pinView!.canShowCallout = true
            
            let btn:UIButton = UIButton(type: UIButtonType.DetailDisclosure)
            pinView!.rightCalloutAccessoryView = btn
            
        }else{
            pinView!.annotation = annotation
        }
        
        if annotation.subtitle! == "Source"{
            pinView!.pinColor = MKPinAnnotationColor.Green
        }else{
            pinView!.pinColor = MKPinAnnotationColor.Red
        }
        
        return pinView;
    }
    
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        
        var circle:MKCircleRenderer = MKCircleRenderer(overlay: overlay)

        if overlay is MKCircle {
                        
            if(overlay.title! == "inner"){
                circle.strokeColor = UIColor(red:255.0/255.0 , green: 204.0/255.0, blue: 0/255.0, alpha: 1.0)
            }else if(overlay.title! == "middle"){
                 circle.strokeColor = UIColor(red:12.0/255.0 , green: 213.0/255.0, blue: 159.0/255.0, alpha: 1.0)
            }else if(overlay.title! == "outer"){
                 circle.strokeColor = UIColor(red:89.0/255.0 , green: 156.0/255.0, blue: 248.0/255.0, alpha: 1.0)
            }
            //circle.fillColor = UIColor.redColor()
            circle.lineWidth = 4.0
            return circle
        }
        
        return circle
    }
    
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
       
        //let capital = view.annotation as! MKPointAnnotation
        let placeName = view.annotation!.title
        let placeInfo = view.annotation!.subtitle
        
       if #available(iOS 8.0, *) {
        let ac = UIAlertController(title: placeName!, message: placeInfo!, preferredStyle: .Alert)
        ac.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))
        presentViewController(ac, animated: true, completion: nil)

        } else {
            // Fallback on earlier versions
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

